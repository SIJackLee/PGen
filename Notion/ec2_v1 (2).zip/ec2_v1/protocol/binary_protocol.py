# binary_protocol.py
# ============================================================
# 역할: Integrator ↔ Receiver 바이너리 프로토콜 코덱
# - STATE_ACK (Integrator → Receiver): pack_state_ack, unpack_state_ack
# - DOWNLINK (Receiver → Integrator): pack_downlink, unpack_downlink
# 바이트 순서: Little-endian (u16, u32)
# 문자열: Length-prefixed [1B len][N bytes ASCII]
# ============================================================

from __future__ import annotations

import struct
from typing import Any, Dict, List, Optional, Tuple


# ============================================================
# 상수
# ============================================================

VER = 0x01
TYPE_STATE_ACK = 0x20
TYPE_DOWNLINK = 0x30

# result (STATE_ACK cmd_ack)
RESULT_OK = 0x00
RESULT_PARTIAL = 0x01
RESULT_FAIL = 0x02
RESULT_TO_STR = {RESULT_OK: "OK", RESULT_PARTIAL: "PARTIAL", RESULT_FAIL: "FAIL"}
STR_TO_RESULT = {v: k for k, v in RESULT_TO_STR.items()}

# state_ack.result (DOWNLINK)
STATE_ACK_OK = 0x00
STATE_ACK_ERR = 0x01

# op (action)
OP_SET_RPM = 0x00
OP_SET_RPM_PCT = 0x01  # MaxRPM 대비 출력 퍼센트 (0~100)


# ============================================================
# 유틸리티
# ============================================================

def _append_len_str(buf: bytearray, s: str) -> None:
    """length-prefixed ASCII 문자열 추가 (1B len + N bytes)"""
    b = s.encode("ascii")
    if len(b) > 255:
        raise ValueError(f"string too long: {len(b)} (max 255)")
    buf.append(len(b))
    buf.extend(b)


def _read_len_str(data: bytes, offset: int) -> Tuple[str, int]:
    """length-prefixed 문자열 읽기. Returns (str, next_offset)"""
    if offset >= len(data):
        raise ValueError("buffer underflow")
    ln = data[offset]
    offset += 1
    if offset + ln > len(data):
        raise ValueError("buffer underflow")
    s = data[offset : offset + ln].decode("ascii")
    return s, offset + ln


# ============================================================
# STATE_ACK (Integrator → Receiver)
# ============================================================

def pack_state_ack(
    key12: str,
    state_ts: int,
    cmd_acks: List[Dict[str, Any]],
) -> bytes:
    """
    STATE_ACK 바이너리 패킹
    
    Args:
        key12: 12자리 ASCII
        state_ts: Unix timestamp (uint32)
        cmd_acks: [{"cmd_id": str, "result": "OK"|"PARTIAL"|"FAIL", "detail": list, "ack_ts": int}, ...]
    
    Returns:
        바이너리 bytes
    """
    if len(key12) != 12:
        raise ValueError(f"key12 must be 12 chars, got {len(key12)}")
    
    buf = bytearray()
    buf.append(VER)
    buf.append(TYPE_STATE_ACK)
    buf.extend(key12.encode("ascii"))
    buf.extend(struct.pack("<I", state_ts & 0xFFFFFFFF))
    buf.append(min(len(cmd_acks), 255))
    
    for ca in cmd_acks[:255]:
        cmd_id = str(ca.get("cmd_id", ""))
        result_str = ca.get("result", "FAIL")
        result = STR_TO_RESULT.get(result_str, RESULT_FAIL)
        ack_ts = int(ca.get("ack_ts", 0)) & 0xFFFFFFFF
        detail = ca.get("detail", [])
        
        _append_len_str(buf, cmd_id)
        buf.append(result)
        buf.extend(struct.pack("<I", ack_ts))
        
        # detail: JSON bytes (opaque)
        import json
        detail_bytes = json.dumps(detail, ensure_ascii=False).encode("utf-8")
        if len(detail_bytes) > 65535:
            detail_bytes = detail_bytes[:65535]
        buf.extend(struct.pack("<H", len(detail_bytes)))
        buf.extend(detail_bytes)
    
    return bytes(buf)


def unpack_state_ack(data: bytes) -> Dict[str, Any]:
    """
    STATE_ACK 바이너리 언패킹
    
    Returns:
        {"ver": int, "type": int, "key12": str, "state_ts": int, "cmd_acks": [...]}
        cmd_acks[i] = {"cmd_id": str, "result": str, "ack_ts": int, "detail": list}
    """
    if len(data) < 19:
        raise ValueError("STATE_ACK too short")
    
    ver = data[0]
    typ = data[1]
    if typ != TYPE_STATE_ACK:
        raise ValueError(f"invalid type: 0x{typ:02x}, expected STATE_ACK")
    
    key12 = data[2:14].decode("ascii")
    state_ts = struct.unpack("<I", data[14:18])[0]
    n = data[18]
    
    cmd_acks = []
    offset = 19
    
    for _ in range(n):
        cmd_id, offset = _read_len_str(data, offset)
        if offset + 5 > len(data):
            raise ValueError("buffer underflow in cmd_ack")
        result = data[offset]
        ack_ts = struct.unpack("<I", data[offset + 1 : offset + 5])[0]
        offset += 5
        
        if offset + 2 > len(data):
            raise ValueError("buffer underflow in detail_len")
        detail_len = struct.unpack("<H", data[offset : offset + 2])[0]
        offset += 2
        if offset + detail_len > len(data):
            raise ValueError("buffer underflow in detail")
        detail_bytes = data[offset : offset + detail_len]
        offset += detail_len
        
        import json
        try:
            detail = json.loads(detail_bytes.decode("utf-8")) if detail_bytes else []
        except Exception:
            detail = []
        
        cmd_acks.append({
            "cmd_id": cmd_id,
            "result": RESULT_TO_STR.get(result, "FAIL"),
            "ack_ts": ack_ts,
            "detail": detail,
        })
    
    return {
        "ver": ver,
        "type": typ,
        "key12": key12,
        "state_ts": state_ts,
        "cmd_acks": cmd_acks,
    }


# ============================================================
# DOWNLINK (Receiver → Integrator)
# ============================================================

def pack_downlink(
    key12: str,
    rx_id: str,
    received_at: int,
    result: int,  # STATE_ACK_OK or STATE_ACK_ERR
    cmds: List[Dict[str, Any]],
) -> bytes:
    """
    DOWNLINK 바이너리 패킹
    
    Args:
        key12: 12자리 ASCII
        rx_id: 수신 ID (예: "sha1:abcd1234...")
        received_at: Unix timestamp
        result: STATE_ACK_OK(0) or STATE_ACK_ERR(1)
        cmds: [{"cmd_id": str, "ttl_sec": int, "actions": [{"eq": str, "op": str, "rpm": int}]}, ...]
    
    Returns:
        바이너리 bytes
    """
    if len(key12) != 12:
        raise ValueError(f"key12 must be 12 chars, got {len(key12)}")
    
    buf = bytearray()
    buf.append(VER)
    buf.append(TYPE_DOWNLINK)
    buf.extend(key12.encode("ascii"))
    _append_len_str(buf, rx_id)
    buf.extend(struct.pack("<I", received_at & 0xFFFFFFFF))
    buf.append(result & 0xFF)
    buf.append(min(len(cmds), 255))
    
    for cmd in cmds[:255]:
        cmd_id = str(cmd.get("cmd_id", ""))
        ttl_sec = int(cmd.get("ttl_sec", 0)) & 0xFFFF
        actions = cmd.get("actions", [])
        
        _append_len_str(buf, cmd_id)
        buf.extend(struct.pack("<H", ttl_sec))
        buf.append(min(len(actions), 255))
        
        for act in actions[:255]:
            eq = str(act.get("eq", "EC01"))[:4].ljust(4)
            op_str = act.get("op", "SET_RPM")
            if op_str == "SET_RPM_PCT":
                op = OP_SET_RPM_PCT
                val = min(100, max(0, int(act.get("pct", 0)))) & 0xFFFF
            else:
                op = OP_SET_RPM
                val = int(act.get("rpm", 0)) & 0xFFFF
            buf.extend(eq.encode("ascii"))
            buf.append(op)
            buf.extend(struct.pack("<H", val))
    
    return bytes(buf)


def unpack_downlink(data: bytes) -> Dict[str, Any]:
    """
    DOWNLINK 바이너리 언패킹
    
    Returns:
        {"ver": int, "type": int, "key12": str, "state_ack": {rx_id, received_at, result}, "cmds": [...]}
        cmds[i] = {"cmd_id": str, "ttl_sec": int, "actions": [{"eq": str, "op": str, "rpm": int}]}
    """
    if len(data) < 15:
        raise ValueError("DOWNLINK too short")
    
    ver = data[0]
    typ = data[1]
    if typ != TYPE_DOWNLINK:
        raise ValueError(f"invalid type: 0x{typ:02x}, expected DOWNLINK")
    
    key12 = data[2:14].decode("ascii")
    rx_id, offset = _read_len_str(data, 14)
    if offset + 6 > len(data):
        raise ValueError("buffer underflow")
    received_at = struct.unpack("<I", data[offset : offset + 4])[0]
    result = data[offset + 4]
    n_cmds = data[offset + 5]
    offset += 6
    
    cmds = []
    for _ in range(n_cmds):
        cmd_id, offset = _read_len_str(data, offset)
        if offset + 3 > len(data):
            raise ValueError("buffer underflow in cmd")
        ttl_sec = struct.unpack("<H", data[offset : offset + 2])[0]
        n_actions = data[offset + 2]
        offset += 3
        
        actions = []
        for _ in range(n_actions):
            if offset + 7 > len(data):
                raise ValueError("buffer underflow in action")
            eq = data[offset : offset + 4].decode("ascii").strip()
            op = data[offset + 4]
            val = struct.unpack("<H", data[offset + 5 : offset + 7])[0]
            offset += 7
            if op == OP_SET_RPM_PCT:
                actions.append({
                    "eq": eq or "EC01",
                    "op": "SET_RPM_PCT",
                    "pct": min(100, val),
                })
            else:
                actions.append({
                    "eq": eq or "EC01",
                    "op": "SET_RPM",
                    "rpm": val,
                })
        
        cmds.append({
            "cmd_id": cmd_id,
            "ttl_sec": ttl_sec,
            "actions": actions,
        })
    
    return {
        "ver": ver,
        "type": typ,
        "key12": key12,
        "state_ack": {
            "rx_id": rx_id,
            "received_at": received_at,
            "result": "OK" if result == STATE_ACK_OK else "ERR",
        },
        "cmds": cmds,
    }


# ============================================================
# MQTT B64 헬퍼
# ============================================================

def decode_b64_payload(mqtt_payload: bytes) -> bytes:
    """
    MQTT payload "B64:..." 디코딩
    
    Args:
        mqtt_payload: MQTT payload bytes
    
    Returns:
        디코딩된 바이너리
    """
    import base64
    text = mqtt_payload.decode("utf-8", errors="replace").strip()
    if "," in text and "B64:" in text:
        text = text.split(",")[-1].strip()
    if text.startswith("B64:"):
        b64 = text[4:]
    else:
        b64 = text
    return base64.b64decode(b64, validate=False)


def encode_b64_payload(binary: bytes) -> str:
    """바이너리를 MQTT B64 payload 문자열로 인코딩"""
    import base64
    return "B64:" + base64.b64encode(binary).decode("ascii")
